# Smart HDD Tester + Fake Card Detector

A separate Android install for offline storage diagnostics with a deliberately destructive USB fake-card capacity test.

## Storage boundaries

The fake-card detector accesses only USB mass-storage devices through a connected USB OTG reader. It does not access internal NAND or the built-in/mounted SD card slot. Ordinary diagnostics remain read-only. The fake-card detector writes test patterns across the USB card and destroys existing data after three explicit confirmations.

Test reports stay in memory and are not saved to internal storage.

## Build

Open the project in Android Studio or use the included Gradle wrapper.

## Source licence

The Smart HDD application is source-available under the project’s personal, non-commercial licence in `LICENSE`. You may inspect it, build it, and make private changes for your own personal use. You may not sell it, use it commercially, or publish a rebranded app based on it. The Gradle wrapper is a separate third-party component under Apache 2.0; see `THIRD_PARTY_NOTICES.md` and `THIRD_PARTY_LICENSES/Apache-2.0.txt`.

## Languages

The app follows the Android system language by default. Settings also lets you choose English, German, Spanish, French, Italian, Brazilian Portuguese, Dutch, Polish, Russian, Japanese, Simplified Chinese, Korean, or Turkish. The main interface, settings, surface-test information, and destructive-test warnings are translated; less common screens and detailed SMART or storage diagnostics may still use English. English is the fallback for any untranslated text. Add new app-facing text to `app/src/main/res/values/strings.xml` and provide matching translations in the locale resource folders.

## Support

The Buy Me a Coffee entry is in About / Support and is optional. Support page: https://buymeacoffee.com/richsretro.


